import os, zipfile
ROOT = r"D:\dsh-free-pane"; VER = "0.10.20-alpha.1"; TOP = "dsh-free-pane-" + VER
OUT = os.path.join(ROOT, "dist", VER, TOP + "-source.zip")
SKIP = {"dist", "node_modules", ".tmp", ".git"}
n = 0
if os.path.exists(OUT): os.remove(OUT)
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = sorted(d for d in dns if d not in SKIP and not d.startswith("."))
        rel = os.path.relpath(dp, ROOT).replace(os.sep, "/")
        for fn in sorted(fns):
            if fn.endswith((".tgz", ".log")): continue
            full = os.path.join(dp, fn)
            arc = TOP + "/" + (fn if rel == "." else rel + "/" + fn)
            zi = zipfile.ZipInfo.from_file(full, arc); zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            with open(full, "rb") as fh: z.writestr(zi, fh.read(), compresslevel=9)
            n += 1
print("files:", n, "size:", os.path.getsize(OUT))
